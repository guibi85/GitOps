# jpashop
CI/CD 파이프라인 구축 테스트
